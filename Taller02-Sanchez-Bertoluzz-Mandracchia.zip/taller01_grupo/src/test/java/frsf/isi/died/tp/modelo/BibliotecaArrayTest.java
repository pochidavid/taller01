package frsf.isi.died.tp.modelo;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class BibliotecaArrayTest {

	@Ignore
	public void testAgregarMaterialCapacitacion() {
		fail("Not yet implemented");
	}

	@Ignore
	public void testCantidadMateriales() {
		fail("Not yet implemented");
	}

	@Ignore
	public void testMateriales() {
		fail("Not yet implemented");
	}

	@Ignore
	public void testCantidadLibros() {
		fail("Not yet implemented");
	}

	@Ignore
	public void testCantidadVideos() {
		fail("Not yet implemented");
	}

	@Ignore
	public void testOrdenarPorPrecio() {
		fail("Not yet implemented");
	}

}
