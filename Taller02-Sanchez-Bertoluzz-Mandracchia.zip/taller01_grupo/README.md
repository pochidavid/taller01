# Taller 01
Taller 01 Java

##Integrantes del grupo##
1. MANDRACCHIA, Alexis David
2. SANCHEZ, Julian Alejandro
3. <Integrante  del grupo>

###Tareas a realizar:###
*	Clonar el repositorio github
*	Completar la clase MaterialCapacitacion
*	Completar la clase Libro
*	Crear la clase Video
*	Implementar la interface Biblioteca
*	Implementar la interface Ordenable
*	Implementar los algoritmos de ordenamiento
*	Enviar el trabajo
